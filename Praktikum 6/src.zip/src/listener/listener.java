package listener;

public class listener 
{

//	System.out.println("Anzahl Zuege: " + dieStrecke.getAnzahlZuege());

}
