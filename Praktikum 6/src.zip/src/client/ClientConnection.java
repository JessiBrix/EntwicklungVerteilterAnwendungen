package client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.Socket;

public class ClientConnection {

    String name;

    private InetAddress group;
    private Socket socket;

    private int port = 4712;

//    public ClientConnection(int seqNr)  {
//        try {
//            socket = new MulticastSocket(port);
//            group = InetAddress.getByName("224.0.0.8");
//            socket.joinGroup(group);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        System.out.println("Verbindung zu " + socket.getInetAddress());
//    }
//
//    public String sendMsg(String dieNachricht) {
//
//        byte[] buf = (dieNachricht).getBytes();
//        DatagramPacket dg = new DatagramPacket(buf, buf.length, group, port);
//        try {
//            socket.send(dg);
//            System.out.println("Senden erfolgreich");
//        } catch (IOException ex) {
//            System.out.println(ex);
//        }
//        return "";
//    }
//}

    public ClientConnection(int seqNr) throws IOException {
        socket = new Socket("localhost", port);
        System.out.println("Verbindung zu " + socket.getInetAddress());
    }

    public String sendMsg(String dieNachricht) throws IOException {
        OutputStream out = socket.getOutputStream();
        byte[] buf = (dieNachricht).getBytes();
        try {
            out.write(buf);
            System.out.println("Senden erfolgreich");
        } catch (IOException ex) {
            System.out.println(ex);
        }
        return "";
    }
}