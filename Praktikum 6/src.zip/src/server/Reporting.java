package server;
public class Reporting
{

    
    public static SyncReporting report = new SyncReporting();
}



class SyncReporting
{
	// Diese Klasse dient nur dazu, die Konsolenausgaben zu synchronisieren
}