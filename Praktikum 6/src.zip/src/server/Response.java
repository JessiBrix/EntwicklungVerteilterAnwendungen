package server;


// Response kann entweder ein MessageResponse oder ein Fault sein.

public class Response 
{

}
