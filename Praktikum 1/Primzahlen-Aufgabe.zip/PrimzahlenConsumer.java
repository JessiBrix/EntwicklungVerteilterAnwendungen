public class PrimzahlenConsumer implements Runnable
{

    private int input;
    Primzahlen meinePrimzahlen;
    private final Thread thread;
   
    public PrimzahlenConsumer(int input, Primzahlen meinePrimzahlen)
    {
        this.input = input;
        this.meinePrimzahlen = meinePrimzahlen;
        thread = new Thread(this);
        thread.start();
    }
    
    
    public boolean istPrimzahl(int l)
    {
    	return meinePrimzahlen.isPrim(l);
    }
        

    public void printPrimzahlen()
    {
        int n = meinePrimzahlen.getLength();
        
        for (int j = 1; j <= n; j++)
        {
            if (meinePrimzahlen.isPrim(j))
            {
                System.out.print(j + " ");
            }
        }
    }

    @Override
    public void run() {
        if(input < PrimzahlenMain.MAXPRIM)
        {

            while (meinePrimzahlen.ready < input){
                long timeToSleep = (input -meinePrimzahlen.ready) * PrimzahlenProducer.MILLIS_BETWEEN_NUMBERS;
                try {
                    Thread.sleep(timeToSleep);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if(istPrimzahl(input))
            {
                System.out.println(input + " ist eine Primzahl");
            }
            else
            {
                System.out.println(input + " ist keine Primzahl");
            }
        }
    }

}