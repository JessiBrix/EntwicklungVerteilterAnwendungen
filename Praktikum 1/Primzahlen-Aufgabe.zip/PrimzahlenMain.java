import java.util.Scanner;



public class PrimzahlenMain
{

    public static final int MAXPRIM = 1000000;
    private int n;
    private Primzahlen meinePrimzahlen;


    public static void main(String[] args)
    {

        Primzahlen meinePrimzahlen = new Primzahlen(MAXPRIM);
        Scanner sc = new Scanner(System.in);

        PrimzahlenProducer pp = new PrimzahlenProducer(meinePrimzahlen);
        int input;
        do
        {
            // Einlesen einer Zahl
            input = sc.nextInt();
            new PrimzahlenConsumer(input, meinePrimzahlen);

        }
        while(input >0);
    }
}
    
